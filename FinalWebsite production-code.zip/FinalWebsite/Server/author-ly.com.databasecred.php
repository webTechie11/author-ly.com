<?php
$dbServerName="localhost";
$dbUsername="root";
$dbPassword="NestedLoop@Authorly#2805";
$dbName="author-ly.com";
$conn=mysqli_connect($dbServerName,$dbUsername,$dbPassword,$dbName);